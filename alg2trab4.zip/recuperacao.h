/* * * * * * * * * * * * * * * * * * *
	Aluno: Mateus Morishigue Borges
	NUSP: 9850328
* * * * * * * * * * * * * * * * * * */

#ifndef RECUPERACAO_H
#define RECUPERACAO_H

int recuperacao(char* readFile);

#endif