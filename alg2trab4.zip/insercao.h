/* * * * * * * * * * * * * * * * * * *
	Aluno: Mateus Morishigue Borges
	NUSP: 9850328
* * * * * * * * * * * * * * * * * * */

#ifndef INSERCAO_H
#define INSERCAO_H

#include <stdio.h>

int insercao(char* readFile, int n);

#endif